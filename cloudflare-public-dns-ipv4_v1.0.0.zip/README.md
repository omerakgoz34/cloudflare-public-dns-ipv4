# cloudflare-public-dns-ipv4
Systemless Cloudflare DNS for IPv4 via Magisk
